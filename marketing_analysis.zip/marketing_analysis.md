```python
import pandas as pd
import matplotlib.pyplot as plt
```


```python
import pandas as pd

df = pd.read_csv(r"C:\Users\write\OneDrive\Desktop\marketing_dataset.2.csv")

df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>Age</th>
      <th>Gender</th>
      <th>City</th>
      <th>CampaignID</th>
      <th>Channel</th>
      <th>Impressions</th>
      <th>Clicks</th>
      <th>Conversions</th>
      <th>Revenue</th>
      <th>Cost</th>
      <th>Date</th>
      <th>CTR</th>
      <th>Conversion_Rate</th>
      <th>ROI</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>36</td>
      <td>Male</td>
      <td>Pune</td>
      <td>CMP106</td>
      <td>YouTube</td>
      <td>1360</td>
      <td>320</td>
      <td>76</td>
      <td>7600</td>
      <td>1924</td>
      <td>2025-03-16</td>
      <td>0.2353</td>
      <td>0.2375</td>
      <td>2.9501</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>19</td>
      <td>Male</td>
      <td>Mumbai</td>
      <td>CMP107</td>
      <td>Facebook</td>
      <td>3944</td>
      <td>149</td>
      <td>28</td>
      <td>2828</td>
      <td>330</td>
      <td>2025-04-18</td>
      <td>0.0378</td>
      <td>0.1879</td>
      <td>7.5697</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>29</td>
      <td>Female</td>
      <td>Hyderabad</td>
      <td>CMP109</td>
      <td>Email</td>
      <td>2933</td>
      <td>241</td>
      <td>64</td>
      <td>7168</td>
      <td>476</td>
      <td>2025-01-22</td>
      <td>0.0822</td>
      <td>0.2656</td>
      <td>14.0588</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>45</td>
      <td>Female</td>
      <td>Delhi</td>
      <td>CMP102</td>
      <td>Email</td>
      <td>3404</td>
      <td>98</td>
      <td>63</td>
      <td>7623</td>
      <td>710</td>
      <td>2025-04-18</td>
      <td>0.0288</td>
      <td>0.6429</td>
      <td>9.7366</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>24</td>
      <td>Male</td>
      <td>Delhi</td>
      <td>CMP104</td>
      <td>Facebook</td>
      <td>1767</td>
      <td>369</td>
      <td>7</td>
      <td>910</td>
      <td>1708</td>
      <td>2025-03-14</td>
      <td>0.2088</td>
      <td>0.0190</td>
      <td>-0.4672</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.groupby("Channel")["Revenue"].sum()
```




    Channel
    Email         1150586
    Facebook      1219867
    Google Ads    1182224
    Instagram     1149984
    YouTube       1160920
    Name: Revenue, dtype: int64




```python
df.groupby("Channel")["CTR"].mean()
```




    Channel
    Email         0.139185
    Facebook      0.128638
    Google Ads    0.138994
    Instagram     0.133909
    YouTube       0.145527
    Name: CTR, dtype: float64




```python
df[["Impressions","Clicks","Conversions","Revenue","Cost"]].corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Impressions</th>
      <th>Clicks</th>
      <th>Conversions</th>
      <th>Revenue</th>
      <th>Cost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Impressions</th>
      <td>1.000000</td>
      <td>-0.020364</td>
      <td>0.006028</td>
      <td>0.009323</td>
      <td>-0.038502</td>
    </tr>
    <tr>
      <th>Clicks</th>
      <td>-0.020364</td>
      <td>1.000000</td>
      <td>-0.006618</td>
      <td>-0.012356</td>
      <td>0.050111</td>
    </tr>
    <tr>
      <th>Conversions</th>
      <td>0.006028</td>
      <td>-0.006618</td>
      <td>1.000000</td>
      <td>0.881815</td>
      <td>-0.002801</td>
    </tr>
    <tr>
      <th>Revenue</th>
      <td>0.009323</td>
      <td>-0.012356</td>
      <td>0.881815</td>
      <td>1.000000</td>
      <td>0.002484</td>
    </tr>
    <tr>
      <th>Cost</th>
      <td>-0.038502</td>
      <td>0.050111</td>
      <td>-0.002801</td>
      <td>0.002484</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.groupby("Channel")["Revenue"].sum().plot(kind="bar")

plt.title("Revenue by Channel")
plt.xlabel("Channel")
plt.ylabel("Revenue")

plt.show()
```


    
![png](output_5_0.png)
    



```python

```
